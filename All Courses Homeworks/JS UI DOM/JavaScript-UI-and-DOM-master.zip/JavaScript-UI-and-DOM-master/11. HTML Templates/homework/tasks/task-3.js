function solve(){
  return function(){
    $.fn.listview = function(data){
      
    };
  };
}

module.exports = solve;