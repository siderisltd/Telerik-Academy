#Task 1 - Tabs

* Create a tabs control using **jQuery** and **wrap it into a plugin**
  * Your are given HTML code in the `index.html` file
    * And a CSS file, that you must use, but not change
  * Using your plugin, make the HTML
  
          
            	<div id="tabs-container">
          			<div class="tab-item">
          				<strong class="tab-item-title">Title 1</strong>
          				<div class="tab-item-content">
          					<h1>Title 1</h1>
          					<div class="content">
          						<p>Contens of the first tab. This is completely meaningless text, <strong>just</strong> to show how the content should look like</p>
          						<ul>
          							<li>And</li>
          							<li>there</li>
          							<li>is</li>
          							<li>a list</li>
          							<li>with <a href="#">link</a></li>					
          						</ul>
          					</div>
          				</div>
          			</div>
          			<div class="tab-item">
          				<strong class="tab-item-title">Title 2</strong>
          				<div class="tab-item-content">
          					<h1>Title 2</h1>
          				</div>
          			</div><div class="tab-item">
          				<strong class="tab-item-title">Title 3</strong>
          				<div class="tab-item-content">					
          					<h1>Title 3</h1>
          				</div>
          			</div><div class="tab-item">
          				<strong class="tab-item-title">Title 4</strong>
          				<div class="tab-item-content">					
          					<h1>Title 4</h1>
          				</div>
          			</div><div class="tab-item">
          				<strong class="tab-item-title">Title 5</strong>
          				<div class="tab-item-content">					
          					<h1>Title 5</h1>
          				</div>
          			</div>
          		</div>
  
  
      * to look like this:<br/>
        <img src="result/tabs-sample.png" />
  
