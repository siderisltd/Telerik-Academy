/* globals $ */
$.fn.gallery = function () {
};