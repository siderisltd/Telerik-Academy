function solve() {
  return function (selector, isCaseSensitive) {
  };
}

module.exports = solve;